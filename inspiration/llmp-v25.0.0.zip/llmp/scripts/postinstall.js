#!/usr/bin/env node

/**
 * LLMemory-Palace v25 - Postinstall Script
 * Sunshine rays logo!
 */

import chalk from 'chalk';

// Colors
const L = chalk.cyanBright;
const L2 = chalk.hex('#4dd4ff');
const M = chalk.magentaBright;
const P = chalk.hex('#ff6b9d');
const ray = chalk.hex('#88ffff');
const ray2 = chalk.hex('#ff88ff');
const glow = chalk.hex('#ffffff');

console.log(`
        ${ray('\\')}   ${ray2('|')}   ${ray('/')}   ${ray('\\')}   ${ray2('|')}   ${ray('/')}   ${ray('\\')}   ${ray2('|')}   ${ray('/')}
         ${ray2('\\')} ${ray('|')} ${ray2('/')}   ${ray('\\')} ${ray2('|')} ${ray('/')}   ${ray2('\\')} ${ray('|')} ${ray2('/')}
          ${ray('\\')}${ray2('|')}${ray('/')}     ${ray2('\\')}${ray('|')}${ray('/')}     ${ray('\\')}${ray2('|')}${ray('/')}
     ${glow('╔═══════════════════════════════════════════════════════╗')}
     ${glow('║')}                                                       ${glow('║')}
     ${glow('║')}   ${L('██╗')}      ${L2('██╗')}      ${M('███╗   ███╗')} ${P('██████╗')}              ${glow('║')}
     ${glow('║')}   ${L('██║')}      ${L2('██║')}      ${M('████╗ ████║')} ${P('██╔══██╗')}             ${glow('║')}
     ${glow('║')}   ${L('██║')}      ${L2('██║')}      ${M('██╔████╔██║')} ${P('██████╔╝')}             ${glow('║')}
     ${glow('║')}   ${L('██║')}      ${L2('██║')}      ${M('██║╚██╔╝██║')} ${P('██╔═══╝')}              ${glow('║')}
     ${glow('║')}   ${L('███████╗')} ${L2('███████╗')} ${M('██║ ╚═╝ ██║')} ${P('██║')}                  ${glow('║')}
     ${glow('║')}   ${L('╚══════╝')} ${L2('╚══════╝')} ${M('╚═╝     ╚═╝')} ${P('╚═╝')}                  ${glow('║')}
     ${glow('║')}                                                       ${glow('║')}
     ${glow('║')}              ▶ ${chalk.hex('#00ffcc')('LLMemory Palace')} ${chalk.white('v25')}                   ${glow('║')}
     ${glow('╚═══════════════════════════════════════════════════════╝')}
          ${ray('/')}${ray2('|')}${ray('\\')}     ${ray2('/')}${ray('|')}${ray2('\\')}     ${ray('/')}${ray2('|')}${ray('\\')}
         ${ray2('/')} ${ray('|')} ${ray2('\\')}   ${ray('/')} ${ray2('|')} ${ray('\\')}   ${ray2('/')} ${ray('|')} ${ray2('\\')}
        ${ray('/')}   ${ray2('|')}   ${ray('\\')}   ${ray2('/')}   ${ray('|')}   ${ray2('\\')}   ${ray('/')}   ${ray2('|')}   ${ray('\\')}
`);

console.log(chalk.white('  LLMemory Palace v25 installed successfully!\n'));

console.log(chalk.dim('  Quick Start:'));
console.log(chalk.cyan('    llmp scan .         ') + chalk.dim('# Scan your project'));
console.log(chalk.cyan('    llmp genome .       ') + chalk.dim('# Generate one-line genome'));
console.log(chalk.cyan('    llmp analyze .      ') + chalk.dim('# Analyze codebase'));
console.log(chalk.cyan('    llmp status         ') + chalk.dim('# Show status'));
console.log(chalk.cyan('    llmp --help         ') + chalk.dim('# Show all commands\n'));

console.log(chalk.dim('  Color Schemes:'));
console.log(chalk.cyan('    llmp status --color neon     ') + chalk.dim('# Cyan + Magenta'));
console.log(chalk.green('    llmp status --color matrix   ') + chalk.dim('# Green'));
console.log(chalk.hex('#ff6b35')('    llmp status --color sunset   ') + chalk.dim('# Orange + Purple'));
console.log(chalk.hex('#00d4ff')('    llmp status --color arctic   ') + chalk.dim('# Ice Blue'));
console.log(chalk.hex('#ff6b9d')('    llmp status --color royal    ') + chalk.dim('# Pink + Purple\n'));

console.log(chalk.magenta('  🧠 LLMP = LLMemory Palace - Compress your codebase!\n'));
