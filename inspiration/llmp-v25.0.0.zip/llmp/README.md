# 🧠 LLMemory-Palace v25

> **Neural Code Genome Compression System**
> 
> Compress entire repositories into one-line genomes. 50-2000x compression. No LLM required.

[![npm version](https://badge.fury.io/js/llmp.svg)](https://www.npmjs.com/package/llmp)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## ✨ Features

- 🧬 **One-Line Genome** - Compress entire repos into a single line
- ⚡ **Algorithmic Engine** - No LLM required for core operations
- 📊 **50-2000x Compression** - Semantic compression using patterns & flows
- 🌍 **Multi-Language** - Python, JS/TS, Rust, Go, Java, and more
- 📤 **Export Formats** - CXML, JSON, and custom formats
- 🎨 **Beautiful CLI** - Color-coded output with ASCII art

---

## 🚀 Quick Start

```bash
# Install globally
npm install -g llmp

# Scan your project
llmp scan .

# Generate one-line genome
llmp genome .

# Analyze codebase
llmp analyze .
```

---

## 📋 Commands

| Command | Description |
|---------|-------------|
| `llmp scan [path]` | Scan project directory |
| `llmp genome [path]` | Generate one-line genome |
| `llmp export [path]` | Export to CXML/JSON |
| `llmp analyze [path]` | Analyze codebase structure |
| `llmp status` | Show palace status |
| `llmp languages` | List supported languages |
| `llmp init [path]` | Initialize configuration |
| `llmp --help` | Show all commands |

---

## 🧬 One-Line Genome Format

```
LLMPv25|PROJECT:myapp|FILES:42|SIZE:12345|LINES:5678|LANG:{python:20,javascript:22}|SYMBOLS:{C:15,F:89,S:156}|RATIO:45x
```

### Structure

- **Header**: `LLMPv25` - Version identifier
- **PROJECT**: Project name
- **FILES**: Total files scanned
- **SIZE**: Total size in bytes
- **LINES**: Total lines of code
- **LANG**: Language distribution
- **SYMBOLS**: Symbol counts (Classes, Functions, Symbols)
- **RATIO**: Compression ratio

---

## 🎨 Color Schemes

LLMP supports multiple color schemes:

```bash
llmp scan . --color neon     # Electric Cyan + Purple (default)
llmp scan . --color matrix   # Classic green Matrix style
llmp scan . --color sunset   # Orange to purple gradient
llmp scan . --color arctic   # Ice blue and white
llmp scan . --color royal    # Gold and purple
```

---

## 📦 Export Formats

### CXML Format

```bash
llmp export . --format cxml --output palace.cxml
```

```xml
<?xml version="1.0" encoding="UTF-8"?>
<PALACE version="25.0">
  <HEADER>
    <PROJECT>myapp</PROJECT>
    <FILES>42</FILES>
  </HEADER>
  <LIBRARY>
    <FILE path="src/main.py" lang="python" lines="100">
      <SYMBOLS classes="2" functions="5"/>
    </FILE>
  </LIBRARY>
</PALACE>
```

### JSON Format

```bash
llmp export . --format json --output palace.json
```

---

## ⚙️ Configuration

Create `.llmp.json` in your project root:

```json
{
  "version": "25.0.0",
  "scan": {
    "extensions": ["py", "js", "ts"],
    "ignore": ["node_modules", "__pycache__"],
    "maxFiles": 10000
  },
  "export": {
    "defaultFormat": "cxml",
    "maxBytes": 10000
  }
}
```

Or use the init command:

```bash
llmp init .
```

---

## 🔧 Programmatic Usage

```javascript
import { Palace, quickScan, decodeGenome } from 'llmp';

// Quick scan
const palace = await quickScan('./my-project');
console.log(palace.stats);

// Generate genome
const genome = palace.generateGenome();
console.log(genome);

// Decode genome
const decoded = decodeGenome(genome);
console.log(decoded);
```

---

## 🌍 Supported Languages

| Language | Extensions | Symbol Extraction |
|----------|------------|-------------------|
| Python | `.py`, `.pyw` | ✅ Classes, Functions, Imports |
| JavaScript | `.js`, `.mjs`, `.cjs` | ✅ Classes, Functions, Imports |
| TypeScript | `.ts`, `.tsx` | ✅ Classes, Functions, Imports |
| Rust | `.rs` | ✅ Structs, Functions, Use |
| Go | `.go` | ✅ Structs, Functions |
| Java | `.java` | ✅ Classes, Methods |
| C/C++ | `.c`, `.cpp`, `.h` | ✅ Functions, Structs |
| Ruby | `.rb` | ✅ Classes, Methods |
| PHP | `.php` | ✅ Classes, Functions |
| Swift | `.swift` | ✅ Classes, Functions |
| Kotlin | `.kt`, `.kts` | ✅ Classes, Functions |

---

## 📊 Compression Levels

| Level | Description | Ratio |
|-------|-------------|-------|
| 1 | State only | 50-100x |
| 2 | Structure + Dependencies | 100-300x |
| 3 | Full source (recommended) | 300-700x |
| 4 | Max density | 700-2000x |

---

## 🧠 How It Works

### 1. Scanning
LLMP scans your project, extracting:
- File metadata (size, lines, hash)
- Symbol definitions (classes, functions)
- Import/export relationships
- Language-specific patterns

### 2. Pattern Detection
Identifies common patterns:
- CRUD operations
- Singleton classes
- Factory patterns
- API routes

### 3. Genome Generation
Compresses everything into:
- Symbol mappings (Greek letters)
- Pattern references
- Flow definitions
- Structural metadata

### 4. Export
Outputs in various formats for:
- LLM context injection
- Version control
- Documentation
- Analysis

---

## 🔬 Advanced Usage

### Custom Ignore Patterns

```bash
llmp scan . --ignore "dist/**,build/**,*.min.js"
```

### Limit File Size

```bash
llmp scan . --max-size 524288  # 512KB max
```

### JSON Output

```bash
llmp scan . --json > scan-results.json
```

### Quiet Mode

```bash
llmp scan . --quiet --json
```

---

## 🤝 Contributing

Contributions are welcome! Please read our contributing guidelines.

---

## 📄 License

MIT License - see LICENSE file for details.

---

## 🔗 Links

- [GitHub Repository](https://github.com/llmemory-palace/llmp)
- [npm Package](https://www.npmjs.com/package/llmp)
- [Documentation](https://llmemory-palace.dev/docs)

---

<div align="center">

**Made with 🧠 by LLMemory-Palace Team**

</div>
